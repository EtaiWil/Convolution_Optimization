
#ifndef _my_func_h
#define _my_func_h
#include "myutil.h"
#include "readBMP.h"

void myfunction(Image *image, char* srcImgpName, char* blurRsltImgName, char* sharpRsltImgName, char* rowBlurRsltImgName, char* rowSharpRsltImgName, char* filteredBlurRsltImgName, char* filteredSharpRsltImgName, char flag);

#endif
