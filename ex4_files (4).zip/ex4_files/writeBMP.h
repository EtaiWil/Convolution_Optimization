#ifndef WRITE_BMP_H_
#define WRITE_BMP_H_

#include "readBMP.h"

void writeBMP(Image *image, const char* originalImgFileName, const char* fileName);

#endif /* WRITE_BMP_H_ */
