#ifndef _show_h
#define _show_h

#include "readBMP.h"

#ifndef __show_private
#define __show_private extern
#endif

__show_private Image *image; // data structure for image
__show_private unsigned long n, m; // width and height

#endif

